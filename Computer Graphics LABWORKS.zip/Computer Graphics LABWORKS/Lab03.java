import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import java.lang.Math;
import javax.swing.JFrame;

public class Lab03 implements GLEventListener {
		   
		private GLU glu;
	   //@Override 

public void init(GLAutoDrawable gld) {
	GL2 gl = gld.getGL().getGL2();
    glu = new GLU();
    gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    gl.glViewport(-250, -150, 250, 150);
    gl.glMatrixMode(GL2.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(-250.0, 250.0, -150.0, 150.0);
}



public void display(GLAutoDrawable drawable) {
    GL2 gl = drawable.getGL().getGL2();

    gl.glClear(GL2.GL_COLOR_BUFFER_BIT);
    /*
     * put your code here
     */

    DrawMPL(gl, 5,60,5,90);
    DrawMPL(gl, 5,60,20,60);
    DrawMPL(gl, 20,30,20,60);
    DrawMPL(gl, 20,60,20,90);
    DrawMPL(gl, 40,30,40,90);
    DrawMPL(gl, 55,30,55,60);
    DrawMPL(gl, 40,30,55,30);
    DrawMPL(gl, 40,60,55,60);
    DrawMPL(gl, 40,90,55,90);
    
    
    

}

public float FindZone(float x1,float y1, float x2, float y2) {
	float dx=x2-x1;
	float dy=y2-y1;
	
	float absDX=Math.abs(dx);
	float absDY=Math.abs(dy);
	
	float zone=0;
	
	if (dx>=0 && dy>=0) {
		if(absDX>absDY) zone=0;
		else zone=1;
	}
	else if (dx<0 && dy>=0) {
		if (absDY>absDX) zone=2;
		else zone=3;
	}
	else if (dx<0 && dy<0) {
		if(absDX>absDY) zone=4;
		else zone=5;
	}
	else if (dx>=0 && dy<0) {
		if (absDY>absDX) zone=6;
		else zone=7;
	}
	else {}
	return zone;
}
private void DrawMPL(GL2 gl, float x1, float y1, float x2, float y2) {
    //write your own code
    gl.glPointSize(2.0f);
    gl.glColor3d(1, 0, 0);
    float x,y;
    float dx,dy;
    float d;
	   float zone=FindZone(x1,y1,x2,y2);
	   float x1New=convertX0(x1,y1,zone);
	   float y1New=convertY0(x1,y1,zone);
	   float x2New=convertX0(x2,y2,zone);
	   float y2New=convertY0(x2,y2,zone);
	   dx=x2New-x1New;
	   dy=y2New-y1New;
	   float dE=2*dy;
	   float dNE=2*(dy-dx);
	   d=(2*dy)-dx;
	   gl.glBegin(GL2.GL_POINTS);
    gl.glVertex2d(x1, y1);
    x=x1New;
    y=y1New;
    while(x<=x2New) {
 	   if(d<0) {
 		   x=x+1;
 		   d=d+dE;
 		   gl.glVertex2d(convertXinit(x,y,zone),convertYinit(x,y,zone));
 	   }
 	   else {
 		   x=x+1;
 		   y=y+1;
 		   d=d+dNE;
 		   gl.glVertex2d(convertXinit(x,y,zone),convertYinit(x,y,zone));
 	   }
 	   
    }
 	   
    gl.glEnd();
 }

 float convertX0(float x, float y, float zone) {
 	float newX=0;
 	
 	if(zone==0) {newX=x;}
 	else if(zone==1) {newX=y;}
 	else if(zone==2) {newX=y;}
 	else if(zone==3) {newX=-x;}
 	else if(zone==4) {newX=-x;}
 	else if(zone==5) {newX=-y;}
 	else if(zone==6) {newX=-y;}
 	else if(zone==7) {newX=x;}
 	return newX;
 }
 float convertY0(float x, float y, float zone) {
 	float newY=0;
 	if(zone==0) {newY=y;}
 	else if(zone==1) {newY=x;}
 	else if(zone==2) {newY=-x;}
 	else if(zone==3) {newY=y;}
 	else if(zone==4) {newY=-y;}
 	else if(zone==5) {newY=-x;}
 	else if(zone==6) {newY=x;}
 	else if(zone==7) {newY=-y;}
 	return newY;
 	
 }
 float convertXinit(float x, float y, float zone) {
 	float newX=0;
 	if(zone==0) {newX=x;}
 	else if(zone==1) {newX=y;}
 	else if(zone==2) {newX=-y;}
 	else if(zone==3) {newX=-x;}
 	else if(zone==4) {newX=-x;}
 	else if(zone==5) {newX=-y;}
 	else if(zone==6) {newX=y;}
 	else if(zone==7) {newX=x;}
 	return newX;
 }
 float convertYinit(float x, float y, float zone) {
 	float newY=0;
 	if(zone==0) {newY=y;}
 	else if(zone==1) {newY=x;}
 	else if(zone==2) {newY=x;}
 	else if(zone==3) {newY=y;}
 	else if(zone==4) {newY=-y;}
 	else if(zone==5) {newY=-x;}
 	else if(zone==6) {newY=-x;}
 	else if(zone==7) {newY=-y;}
 	return newY;
 	
 }




public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}


public void dispose(GLAutoDrawable arg0)
{
 
}

public static void main(String args[]){
 //getting the capabilities object of GL2 profile
 final GLProfile profile=GLProfile.get(GLProfile.GL2);
 GLCapabilities capabilities=new GLCapabilities(profile);
 // The canvas
 final GLCanvas glcanvas=new GLCanvas(capabilities);
 Lab03 l = new Lab03();
 //ThirdGLEventListener b=new ThirdGLEventListener();
 glcanvas.addGLEventListener(l);
 glcanvas.setSize(400, 400);
 //creating frame
 final JFrame frame=new JFrame("MPL");
 //adding canvas to frame
 frame.add(glcanvas);
 frame.setSize(640,480);
 frame.setVisible(true);
}
}