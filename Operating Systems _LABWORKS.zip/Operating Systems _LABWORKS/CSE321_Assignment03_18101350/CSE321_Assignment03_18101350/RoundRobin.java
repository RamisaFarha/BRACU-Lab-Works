import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class RoundRobin {

 public static void main(String[] args) {
  // TODO Auto-generated method stub
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter number of processes: ");
  int num = sc.nextInt();
  int[]pid = new int[num];
  int[]arrival_time = new int[num];
  int[]burst_time = new int[num];
  int[]pBurstTime = new int[num];
  int[]complete_time = new int[num];
  int[]turnaround_time = new int[num];
  int[]waiting_time = new int[num];
  int[]flag = new int[num];
  int systemTime = 0;
  int tot= 0;
  float avgWaiting = 0;
  float avgTurn = 0;
  
  
  
  Queue<Integer>waitingQueue = new LinkedList<Integer>();
  System.out.println("Time Quantum :");
  int tQ = sc.nextInt();
  for(int i=0; i<num; ++i) {
   System.out.println("Enter process "+(i+1)+"'s Arrival Time");
   arrival_time[i] = sc.nextInt();
   System.out.println("Enter process "+(i+1)+"'s Burst Time");
   burst_time[i] = sc.nextInt();
   pBurstTime[i] = burst_time[i];
   pid[i] = i+1;
   flag[i] = 0;
  }
  
  while(true) {
   int count=num;
   if(tot == num) {
    break;
   }
   for(int i = 0; i<num ; ++i) {
    if(arrival_time[i]<=systemTime && flag[i]==0 && !waitingQueue.contains(i)) {
     waitingQueue.add(i);
    }
    
   }
   
   if(!waitingQueue.isEmpty()) {
    count=waitingQueue.peek();
    
    if(burst_time[count]>tQ) {
     burst_time[count]-=tQ;
     systemTime+=tQ;
     for(int i = 0; i<num ; ++i) {
      if(arrival_time[i]<=systemTime && flag[i]==0 && !waitingQueue.contains(i)) {
       waitingQueue.add(i);
      }
      
     }
     waitingQueue.remove();
     waitingQueue.add(count);
     
    }else {
     systemTime+=burst_time[count];
     burst_time[count]=0;
     flag[count]=1;
     complete_time[count] = systemTime; 
     tot++;
     waitingQueue.remove();
    }
   }
   else{
    systemTime++;
   }
   
  }
  for(int i=0; i<num; ++i) {
   turnaround_time[i]=complete_time[i]-arrival_time[i];
   avgTurn+=turnaround_time[i];
   waiting_time[i]=turnaround_time[i]-pBurstTime[i];
   avgWaiting+=waiting_time[i];
  }
  avgTurn/=num;
  avgWaiting/=num;
  System.out.println("\npid  arrival brust  complete turn waiting");
  for(int i=0; i<num; ++i) {
   System.out.println(pid[i]+"\t"+arrival_time[i]+"\t"+pBurstTime[i]+"\t"+complete_time[i]+"\t"+turnaround_time[i]+"\t"+waiting_time[i]);
  }
  System.out.println("Average Turnaround Time = "+avgTurn+"\nAverage Waiting Time = "+avgWaiting);
  sc.close();
 
 }

}






