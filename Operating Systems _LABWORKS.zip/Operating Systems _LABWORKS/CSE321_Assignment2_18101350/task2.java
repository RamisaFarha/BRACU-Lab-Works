import java.util.ArrayList;
import java.util.*;
public class task2{
    public static void main(String[]args){
        ///ArrayList<Integer>  maxNumber = new ArrayList<>();
        newThread Thread0 =new newThread("Therad 0");
        newThread Thread1 =new newThread("Therad 1");
        newThread Thread2 =new newThread("Therad 2");
        newThread Thread3 =new newThread("Therad 3");
        newThread Thread4 =new newThread("Therad 4");
        newThread Thread5 =new newThread("Therad 5");
        newThread Thread6 =new newThread("Therad 6");
        newThread Thread7 =new newThread("Therad 7");
        newThread Thread8 =new newThread("Therad 8");
        newThread Thread9 =new newThread("Therad 9");
        Thread0.run();
        Thread1.run();
        Thread2.run();
        Thread3.run();
        Thread4.run();
        Thread5.run();
        Thread6.run();
        Thread7.run();
        Thread8.run();
        Thread9.run();
        
        
    }
}
class newThread extends Thread{
    static int number=1;
    ArrayList<Integer>  maxNumber = new ArrayList<>();
    public newThread(String name){
        super(name);
    }
    
    public void run(){
        int max=0;
        int maxValue=0;
        for(int i=number;i<number+10000;i++){
            int sum=0;
            for(int j=1;j<=i;j++){
                if(i%j==0)
                    sum++;
            }
            if(sum>max){
                max=sum;
                maxValue= i;
            }
        }
        maxNumber.add(maxValue);
        //System.out.println("In range of "+number+" to "+(number+10000-1)+", " +maxValue+"that has the largest number of divisors");
        number+=10000;
        if(getName().equals("Therad 9")){
         Collections.sort(maxNumber);
                  
          System.out.println(maxNumber.get(0)+" has the largest number of divisors from the results from Thread-0 to Thread-9.");
        }
    }
      
    
}