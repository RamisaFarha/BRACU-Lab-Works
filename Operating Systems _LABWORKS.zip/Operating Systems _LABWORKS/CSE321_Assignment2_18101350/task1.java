public class task1 {
    
    public static void main(String[] args) {
        
        MyThread myThread1 = new MyThread("Thread 1");
        MyThread myThread2 = new MyThread("Thread 2");
        
        myThread1.run();
        myThread2.run();
        myThread1.run();
        
    }
    
}
class MyThread extends Thread{
    static int n=1;
    public MyThread(String threadName){
        super(threadName);
    }
    
    public void run(){
        for(int i=n;i<n+10;i++){
            System.out.println("From "+ getName()+": "+ i);
            try{
            sleep(1000);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        }
        System.out.println();
        try{
            sleep(1000);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        n+=10;
        
    }
    
}

