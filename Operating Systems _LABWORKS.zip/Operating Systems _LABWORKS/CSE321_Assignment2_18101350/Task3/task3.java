import java.util.*;
import java.util.Arrays;
public class task3{
  static int a[]={6,6,2,3,8,4,9,3,77};
    public static void main(String[]args){
        
        
        
        singleMergeSort thread1=new singleMergeSort(a,0,a.length-1);
        long currentTimeInNanoSecond = System.nanoTime();
        thread1.run();
        System.out.println(Arrays.toString(a));
        
// task starts
// task ends
        long executionTimeInNanoSecond = System.nanoTime() - currentTimeInNanoSecond;
        System.out.println(executionTimeInNanoSecond);
        System.out.println("---------------------");
        MergeSort Thread2 = new MergeSort(a,0,a.length-1);  
         long currentTimeInNanoSecond1= System.nanoTime();
        Thread2.run();
        System.out.println(Arrays.toString(a));
        long executionTimeInNanoSecond1 = System.nanoTime() - currentTimeInNanoSecond1;
        System.out.println(executionTimeInNanoSecond1);
        
        //MYThread Thread1 =new MYThread();
        //Thread1.run();
       
    }
}
